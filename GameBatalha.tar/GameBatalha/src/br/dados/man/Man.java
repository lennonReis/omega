
package br.dados.man;

import java.util.Scanner;

public class Man {
    
    
    public static void main(String[] args) {
        
      
        Scanner input = new Scanner(System.in);
        
        
    }
    
}
